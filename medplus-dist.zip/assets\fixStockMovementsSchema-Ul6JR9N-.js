import{s as e}from"./index-Bn5x-3I5.js";async function n(){try{console.log("Checking stock_movements table schema...");const{error:t}=await e.from("stock_movements").select("id").limit(1);if(t&&t.code==="PGRST116")throw new Error("Stock movements table does not exist. Please create it first using the Database Schema Initializer.");const{error:a}=await e.from("stock_movements").select("updated_at").limit(1);if(a&&a.message.includes("updated_at")){console.log("updated_at column missing, adding it...");try{const{error:o}=await e.rpc("exec_sql",{sql:"ALTER TABLE stock_movements ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();"});if(o)throw new Error(`Failed to add column: ${o.message}`);const{error:r}=await e.rpc("exec_sql",{sql:"UPDATE stock_movements SET updated_at = COALESCE(created_at, NOW()) WHERE updated_at IS NULL;"});r&&console.warn("Failed to update existing rows, but column was added successfully:",r);const{error:s}=await e.rpc("exec_sql",{sql:`
            CREATE OR REPLACE FUNCTION update_stock_movements_updated_at()
            RETURNS TRIGGER AS $$
            BEGIN
              NEW.updated_at = NOW();
              RETURN NEW;
            END;
            $$ LANGUAGE plpgsql;
          `});s&&console.warn("Failed to create trigger function:",s);const{error:c}=await e.rpc("exec_sql",{sql:`
            DROP TRIGGER IF EXISTS trigger_update_stock_movements_updated_at ON stock_movements;
            CREATE TRIGGER trigger_update_stock_movements_updated_at
              BEFORE UPDATE ON stock_movements
              FOR EACH ROW EXECUTE FUNCTION update_stock_movements_updated_at();
          `});c&&console.warn("Failed to create trigger:",c)}catch(o){console.error("RPC method failed, trying alternative approach:",o);const{error:r}=await e.rpc("exec_sql",{sql:"ALTER TABLE stock_movements ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW();"});if(r)throw new Error(`All methods failed. Last error: ${r.message}. Please use the manual SQL approach.`)}if(addColumnError)throw console.error("Error adding updated_at column:",addColumnError),new Error(`Failed to add updated_at column: ${addColumnError.message}`);return console.log("✅ Successfully added updated_at column to stock_movements table"),{success:!0,message:"updated_at column added successfully"}}else return console.log("✅ updated_at column already exists"),{success:!0,message:"updated_at column already exists"}}catch(t){return console.error("Error fixing stock movements schema:",t),{success:!1,error:t instanceof Error?t.message:"Unknown error occurred"}}}export{n as fixStockMovementsSchema};
